// ข้อมูลผู้ส่ง (แก้เป็นของคุณ)
const SHOP = { name: 'ร้านน้ำผึ้ง', address: 'ใส่ที่อยู่ร้าน', phone: '0000000000' };
const PRICES = { HNY250: 120, HNY500: 220 };
const HEADERS = ['id', 'date', 'name', 'phone', 'address', 'subdistrict', 'district',
  'province', 'zipcode', 'HNY250', 'HNY500', 'total', 'status'];
const FIELDS = ['name', 'phone', 'address', 'subdistrict', 'district', 'province', 'zipcode'];
const STATUSES = ['ใหม่', 'หยิบแล้ว', 'แพ็คแล้ว', 'ส่งแล้ว'];

function getSheet_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sh = ss.getSheetByName('Orders');
  if (!sh) {
    sh = ss.insertSheet('Orders');
    sh.appendRow(HEADERS);
    // เก็บเป็นข้อความ เพื่อไม่ให้เลข 0 หน้าเบอร์โทรหาย
    sh.getRange('A:I').setNumberFormat('@');
  }
  return sh;
}

function json_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}

// กันข้อความที่ขึ้นต้นเหมือนสูตร
function clean_(v) {
  const s = String(v || '').trim().slice(0, 300);
  return /^[=+\-@]/.test(s) ? "'" + s : s;
}

function doPost(e) {
  const lock = LockService.getScriptLock();
  try {
    lock.waitLock(20000);
    const d = JSON.parse(e.postData.contents);
    if (d.action === 'order') return json_(addOrder_(d));

    const key = PropertiesService.getScriptProperties().getProperty('ADMIN_KEY');
    if (!key || d.key !== key) throw new Error('รหัสผู้ดูแลไม่ถูกต้อง');

    const sh = getSheet_();
    const rows = sh.getDataRange().getValues().slice(1);
    if (d.action === 'list') {
      const orders = rows.map(r => Object.fromEntries(HEADERS.map((h, i) => [h, r[i]])));
      return json_({ ok: true, orders: orders, shop: SHOP });
    }
    if (d.action === 'status' && STATUSES.indexOf(d.status) >= 0) {
      rows.forEach((r, i) => {
        if (d.ids.indexOf(r[0]) >= 0) sh.getRange(i + 2, HEADERS.length).setValue(d.status);
      });
      return json_({ ok: true });
    }
    throw new Error('คำสั่งไม่ถูกต้อง');
  } catch (err) {
    return json_({ ok: false, error: err.message });
  } finally {
    lock.releaseLock();
  }
}

function addOrder_(d) {
  FIELDS.forEach(f => { if (!String(d[f] || '').trim()) throw new Error('กรอกข้อมูลไม่ครบ'); });
  const qty = Object.keys(PRICES).map(k => {
    const n = Number(d[k] || 0);
    if (!Number.isInteger(n) || n < 0 || n > 50) throw new Error('จำนวนสินค้าไม่ถูกต้อง');
    return n;
  });
  // คำนวณราคาฝั่งเซิร์ฟเวอร์
  const total = Object.keys(PRICES).reduce((s, k, i) => s + PRICES[k] * qty[i], 0);
  if (total <= 0) throw new Error('ยังไม่ได้เลือกสินค้า');

  const now = new Date();
  const id = 'HN' + Utilities.formatDate(now, 'Asia/Bangkok', 'yyMMdd-HHmmss') +
    '-' + Math.floor(100 + Math.random() * 900);
  const date = Utilities.formatDate(now, 'Asia/Bangkok', 'yyyy-MM-dd HH:mm');
  const row = [id, date].concat(FIELDS.map(f => clean_(d[f])), qty, [total, STATUSES[0]]);

  const sh = getSheet_();
  const range = sh.getRange(sh.getLastRow() + 1, 1, 1, row.length);
  range.offset(0, 0, 1, 9).setNumberFormat('@');
  range.setValues([row]);
  return { ok: true, id: id, total: total };
}
